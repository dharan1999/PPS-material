

public interface PubliclyCloneable extends Cloneable
{
    public Object clone();
}
